package Observer;
public interface Observer
{
    public void notificar(String nome, float valor);
}