package Template;
public class PizzaCalabresa extends Pizza
{

    @Override
    public void recheio() {
        System.out.println("Recheio de calabresa.");
    }
}
