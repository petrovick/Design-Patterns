package Template;
public class PizzaPortuguesa extends Pizza
{
    @Override
    public void recheio() {
        System.out.println("Recheio de pizza portuguesa.");
    }
    
}
