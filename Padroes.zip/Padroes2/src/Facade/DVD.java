package Facade;
public class DVD
{
    public void colocarDisco()
    {
        System.out.println("Colocar disco...");
    }
    
    public void escolherIdioma()
    {
        System.out.println("Escolhendo idioma...");
    }
    
    public void apertarPlay()
    {
        System.out.println("Apertando o play...");
    }
    
}
