package Facade;
public class Main
{
    public static void main(String ...args)
    {
        FacadeDVD fdvd = new FacadeDVD();
        fdvd.assistirOFilme();
    }
}
