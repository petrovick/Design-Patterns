package Composite;
public interface Produto
{
    public float getPreco();
    public String getDesricao();
}
