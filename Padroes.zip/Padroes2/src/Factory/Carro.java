package Factory;
public interface Carro
{
    public void nomeCarro();
}
