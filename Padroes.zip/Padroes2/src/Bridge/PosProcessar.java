package Bridge;

public interface PosProcessar {
    public void PorProcessar();
}
