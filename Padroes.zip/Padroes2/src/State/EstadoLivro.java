package State;
public interface EstadoLivro
{
    public boolean devolver(Livro livro);
    public void solicitar(Livro livro);
    
}
